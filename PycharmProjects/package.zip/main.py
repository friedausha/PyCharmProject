import json
import requests
from database import Database
import boto3

def get_list_places(code):
    url = "http://www.kawalpemilu.org/api/children/" + str(code) + "?_=1538026960934"
    returned_json = requests.get(url)
    list_places = json.loads(returned_json.text)
    return list_places


def get_tps(code):
    url_tps = "http://www.kawalpemilu.org/api/tps/" + str(code) + "?_=1538026960934"
    returned_json = requests.get(url_tps)
    result = json.loads(returned_json.text)
    print(result)
    return result


def save_result(result, database, code):
    for tps in range(len(result)):
        sql = "INSERT INTO hasil (prabowo, jokowi, suara_sah, suara_tidak_sah) VALUES (%s, %s, %s, %s)"
        val = (result[tps][2], result[tps][3], result[tps][4], result[tps][5])
        database.get_cursor().execute(sql, val)
        database.commit()
        filename = str(code).zfill(7) + str(tps + 1).zfill(3) + '04.jpg'
        result_pic_url = "http://scanc1.kpu.go.id/viewp.php?f=" + filename
        print(result_pic_url)
        save_image(result_pic_url, filename)


def save_image(url_image, filename):
    session = boto3.Session(aws_access_key_id='AKIAIQ2PJXOKYG3NNPYQ',
                      aws_secret_access_key='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',
                      region_name='ap-southeast-1')

    bucketName = "kawal.pemilu"
    # Key = Image.open((url_image))
    req_for_image = requests.get(url_image, stream=True)
    file_object_from_req = req_for_image.raw
    req_data = file_object_from_req.read()
    s3 = session.resource('s3')
    s3.Bucket(bucketName).put_object(Key=filename, Body=req_data)


def main():
    database = Database()
    database.create_table()
    list_provinces = get_list_places(0)
    for province in range(len(list_provinces)):
        list_kabupaten = get_list_places(list_provinces[province][0])
        for kabupaten in range(len(list_kabupaten)):
            list_kecamatan = get_list_places(list_kabupaten[kabupaten][0])
            for kecamatan in range(len(list_kecamatan)):
                list_kelurahan = get_list_places(list_kecamatan[kecamatan][0])
                for kelurahan in range(len(list_kelurahan)):
                   list_tps = get_tps(list_kelurahan[kelurahan][0])
                   save_result(list_tps, database, list_kelurahan[kelurahan][0])


main()
